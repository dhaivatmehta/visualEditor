class EditorsController < ApplicationController
  def index
  end
end
